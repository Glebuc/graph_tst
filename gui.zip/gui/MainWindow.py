
from PySide6.QtWidgets import *
from ui_functions import UIFunctions
from ui_mainwindow import Ui_MainWindow
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import (QAbstractItemView, QDataWidgetMapper,
    QHeaderView, QMainWindow, QMessageBox)
from PySide6.QtGui import QKeySequence
from PySide6.QtSql import QSqlRelation, QSqlRelationalTableModel, QSqlTableModel
from PySide6.QtCore import Qt, Slot
import database.Model_result



import sys





class Ui(QMainWindow):
    """Основное окно и подгружаемый ui-файл Qt"""
    def __init__(self, parent=None):
        super(Ui, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.show()
        self.setWindowTitle("TsT Graph")
        self.setWindowIcon(QIcon('./static/main_icon.svg'))
        self.setMinimumSize(800,600)
        self.ui.stackedWidget.setCurrentWidget(self.ui.page_report)
        # self.model = Result.View()
        # self.ui.tableView.setModel(self.model)
        ## TOGGLE MENU
        self.ui.burger_btn.clicked.connect(lambda: UIFunctions.toggleMenu(self, 250, True))


        self.ui.burger_btn.clicked.connect(UIFunctions.toggle_text)


        # self.ui.home_btn.clicked.connect(UIFunctions.set_active_btn(self))

        # REPORT PAGE
        self.ui.report_btn.clicked.connect(lambda: self.ui.stackedWidget.setCurrentWidget(self.ui.page_report))

        # CHART PAGE
        self.ui.chart_btn.clicked.connect(lambda: self.ui.stackedWidget.setCurrentWidget(self.ui.page_chart))

        # RESULT PAGE
        self.ui.result_btn.clicked.connect(lambda: self.ui.stackedWidget.setCurrentWidget(self.ui.page_result))

        # SETTING PAGE
        self.ui.setting_btn.clicked.connect(lambda: self.ui.stackedWidget.setCurrentWidget(self.ui.page_setting))

        self.ui.pushButton_9.clicked.connect(UIFunctions.open_dialog_search)

        self.ui.pushButton_3.clicked.connect(UIFunctions.check_connection_database)

        database.Model_result.init_db()

        model = QSqlRelationalTableModel(self.bookTable)
        model.setEditStrategy(QSqlTableModel.OnManualSubmit)
        model.setTable("books")

        # Remember the indexes of the columns:
        author_idx = model.fieldIndex("author")
        genre_idx = model.fieldIndex("genre")

        # Set the relations to the other database tables:
        model.setRelation(author_idx, QSqlRelation("authors", "id", "name"))
        model.setRelation(genre_idx, QSqlRelation("genres", "id", "name"))

        # Set the localized header captions:
        model.setHeaderData(author_idx, Qt.Horizontal, self.tr("Author Name"))
        model.setHeaderData(genre_idx, Qt.Horizontal, self.tr("Genre"))
        model.setHeaderData(model.fieldIndex("title"), Qt.Horizontal, self.tr("Title"))
        model.setHeaderData(model.fieldIndex("year"), Qt.Horizontal, self.tr("Year"))
        model.setHeaderData(model.fieldIndex("rating"), Qt.Horizontal, self.tr("Rating"))

        if not model.select():
            print(model.lastError())

    # self.db_manager = DatabaseManager()
        # self.data = self.db_manager.execute_query("SELECT * FROM tests")
        # self.headers = ["Column1", "Column2", "Column3"]  # Replace with actual column name
        #
        #
        # self.tableView = QTableView(self)
        # self.model = CustomTableModel(self.data, self.headers, self)
        # self.tableView.setModel(self.model)

        # self.ui.tableView(self.tableView)
        # self.setGeometry(100, 100, 800, 600)
        # self.setWindowTitle("Data from PostgreSQL in QTableView")
        # self.show()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = Ui()
    window.show()
    sys.exit(app.exec())