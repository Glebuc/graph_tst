# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.5.2
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x03\xc9\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0a<svg fill=\
\x22#000000\x22 width=\
\x22800px\x22 height=\x22\
800px\x22 viewBox=\x22\
-1 0 19 19\x22 xmln\
s=\x22http://www.w3\
.org/2000/svg\x22 c\
lass=\x22cf-icon-sv\
g\x22><path d=\x22M16.\
417 9.583A7.917 \
7.917 0 1 1 8.5 \
1.666a7.917 7.91\
7 0 0 1 7.917 7.\
917zm-2.882-2.62\
5a.396.396 0 0 0\
-.396-.396h-.855\
a1.58 1.58 0 0 0\
-3.058 0H3.912a.\
396.396 0 0 0 0 \
.792h5.314a1.58 \
1.58 0 0 0 3.058\
 0h.855a.396.396\
 0 0 0 .396-.396\
zm0 2.63a.396.39\
6 0 0 0-.396-.39\
6H7.825a1.58 1.5\
8 0 0 0-3.058 0h\
-.855a.396.396 0\
 0 0 0 .792h.855\
a1.58 1.58 0 0 0\
 3.058 0h5.314a.\
396.396 0 0 0 .3\
96-.396zm0 2.63a\
.396.396 0 0 0-.\
396-.396h-.855a1\
.58 1.58 0 0 0-3\
.058 0H3.912a.39\
6.396 0 1 0 0 .7\
91h5.314a1.58 1.\
58 0 0 0 3.058 0\
h.855a.396.396 0\
 0 0 .396-.396zm\
-6.452-2.63a.788\
.788 0 1 1-.787-\
.788.788.788 0 0\
 1 .787.788zm4.4\
6-2.63a.787.787 \
0 1 1-.788-.787.\
788.788 0 0 1 .7\
87.787zm0 5.26a.\
787.787 0 1 1-.7\
88-.788.788.788 \
0 0 1 .787.787z\x22\
/></svg>\
\x00\x00\x04-\
<\
?xml version=\x221.\
0\x22 ?>\x0a\x0d<!-- Uplo\
aded to: SVG Rep\
o, www.svgrepo.c\
om, Generator: S\
VG Repo Mixer To\
ols -->\x0a<svg fil\
l=\x22#000000\x22 widt\
h=\x22800px\x22 height\
=\x22800px\x22 viewBox\
=\x220 0 512 512\x22 i\
d=\x22_x30_1\x22 versi\
on=\x221.1\x22 xml:spa\
ce=\x22preserve\x22 xm\
lns=\x22http://www.\
w3.org/2000/svg\x22\
 xmlns:xlink=\x22ht\
tp://www.w3.org/\
1999/xlink\x22>\x0a\x0d<g\
>\x0a\x0d<path d=\x22M256\
,0C114.615,0,0,1\
14.615,0,256s114\
.615,256,256,256\
s256-114.615,256\
-256S397.385,0,2\
56,0z M390.062,3\
75.438   c0,20.1\
93-16.37,36.562-\
36.562,36.562h-1\
95c-20.193,0-36.\
562-16.37-36.562\
-36.562V136.562c\
0-20.193,16.37-3\
6.562,36.562-36.\
562H256   c20.19\
3,0,36.562,16.37\
,36.562,36.562v2\
4.375c0,20.193,1\
6.37,36.562,36.5\
62,36.562H353.5c\
20.193,0,36.562,\
16.37,36.562,36.\
562   V375.438z\x22\
/>\x0a\x0d<path d=\x22M32\
3.031,253.562H18\
8.969c-10.096,0-\
18.281,8.185-18.\
281,18.281s8.185\
,18.281,18.281,1\
8.281h134.062   \
c10.096,0,18.281\
-8.185,18.281-18\
.281S333.128,253\
.562,323.031,253\
.562z\x22/>\x0a\x0d<path \
d=\x22M323.031,326.\
688H188.969c-10.\
096,0-18.281,8.1\
85-18.281,18.281\
s8.185,18.281,18\
.281,18.281h134.\
062   c10.096,0,\
18.281-8.185,18.\
281-18.281S333.1\
28,326.688,323.0\
31,326.688z\x22/>\x0a\x0d\
</g>\x0a\x0d</svg>\
\x00\x00\x04-\
<\
?xml version=\x221.\
0\x22 ?>\x0a\x0d<!-- Uplo\
aded to: SVG Rep\
o, www.svgrepo.c\
om, Generator: S\
VG Repo Mixer To\
ols -->\x0a<svg fil\
l=\x22#000000\x22 widt\
h=\x22800px\x22 height\
=\x22800px\x22 viewBox\
=\x220 0 512 512\x22 i\
d=\x22_x30_1\x22 versi\
on=\x221.1\x22 xml:spa\
ce=\x22preserve\x22 xm\
lns=\x22http://www.\
w3.org/2000/svg\x22\
 xmlns:xlink=\x22ht\
tp://www.w3.org/\
1999/xlink\x22>\x0a\x0d<g\
>\x0a\x0d<path d=\x22M256\
,0C114.615,0,0,1\
14.615,0,256s114\
.615,256,256,256\
s256-114.615,256\
-256S397.385,0,2\
56,0z M390.062,3\
75.438   c0,20.1\
93-16.37,36.562-\
36.562,36.562h-1\
95c-20.193,0-36.\
562-16.37-36.562\
-36.562V136.562c\
0-20.193,16.37-3\
6.562,36.562-36.\
562H256   c20.19\
3,0,36.562,16.37\
,36.562,36.562v2\
4.375c0,20.193,1\
6.37,36.562,36.5\
62,36.562H353.5c\
20.193,0,36.562,\
16.37,36.562,36.\
562   V375.438z\x22\
/>\x0a\x0d<path d=\x22M32\
3.031,253.562H18\
8.969c-10.096,0-\
18.281,8.185-18.\
281,18.281s8.185\
,18.281,18.281,1\
8.281h134.062   \
c10.096,0,18.281\
-8.185,18.281-18\
.281S333.128,253\
.562,323.031,253\
.562z\x22/>\x0a\x0d<path \
d=\x22M323.031,326.\
688H188.969c-10.\
096,0-18.281,8.1\
85-18.281,18.281\
s8.185,18.281,18\
.281,18.281h134.\
062   c10.096,0,\
18.281-8.185,18.\
281-18.281S333.1\
28,326.688,323.0\
31,326.688z\x22/>\x0a\x0d\
</g>\x0a\x0d</svg>\
\x00\x00\x02{\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0a<svg fill=\
\x22#000000\x22 width=\
\x22800px\x22 height=\x22\
800px\x22 viewBox=\x22\
0 0 36 36\x22 versi\
on=\x221.1\x22  preser\
veAspectRatio=\x22x\
MidYMid meet\x22 xm\
lns=\x22http://www.\
w3.org/2000/svg\x22\
 xmlns:xlink=\x22ht\
tp://www.w3.org/\
1999/xlink\x22>\x0a   \
 <title>error-so\
lid</title>\x0a    \
<path class=\x22clr\
-i-solid clr-i-s\
olid-path-1\x22 d=\x22\
M18,6A12,12,0,1,\
0,30,18,12,12,0,\
0,0,18,6Zm-1.49,\
6a1.49,1.49,0,0,\
1,3,0v6.89a1.49,\
1.49,0,1,1-3,0ZM\
18,25.5a1.72,1.7\
2,0,1,1,1.72-1.7\
2A1.72,1.72,0,0,\
1,18,25.5Z\x22></pa\
th>\x0a    <rect x=\
\x220\x22 y=\x220\x22 width=\
\x2236\x22 height=\x2236\x22\
 fill-opacity=\x220\
\x22/>\x0a</svg>\
\x00\x00\x02{\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0a<svg fill=\
\x22#000000\x22 width=\
\x22800px\x22 height=\x22\
800px\x22 viewBox=\x22\
0 0 36 36\x22 versi\
on=\x221.1\x22  preser\
veAspectRatio=\x22x\
MidYMid meet\x22 xm\
lns=\x22http://www.\
w3.org/2000/svg\x22\
 xmlns:xlink=\x22ht\
tp://www.w3.org/\
1999/xlink\x22>\x0a   \
 <title>error-so\
lid</title>\x0a    \
<path class=\x22clr\
-i-solid clr-i-s\
olid-path-1\x22 d=\x22\
M18,6A12,12,0,1,\
0,30,18,12,12,0,\
0,0,18,6Zm-1.49,\
6a1.49,1.49,0,0,\
1,3,0v6.89a1.49,\
1.49,0,1,1-3,0ZM\
18,25.5a1.72,1.7\
2,0,1,1,1.72-1.7\
2A1.72,1.72,0,0,\
1,18,25.5Z\x22></pa\
th>\x0a    <rect x=\
\x220\x22 y=\x220\x22 width=\
\x2236\x22 height=\x2236\x22\
 fill-opacity=\x220\
\x22/>\x0a</svg>\
\x00\x00\x02\x9c\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0a<svg fill=\
\x22#000000\x22 width=\
\x22800px\x22 height=\x22\
800px\x22 viewBox=\x22\
-1 0 19 19\x22 xmln\
s=\x22http://www.w3\
.org/2000/svg\x22 c\
lass=\x22cf-icon-sv\
g\x22><path d=\x22M16.\
417 9.583A7.917 \
7.917 0 1 1 8.5 \
1.666a7.917 7.91\
7 0 0 1 7.917 7.\
917zm-4.233-1.80\
5H9.259a.318.318\
 0 0 1-.317-.317\
v-2.9H5.16a.318.\
318 0 0 0-.316.3\
17v9.367a.318.31\
8 0 0 0 .316.317\
h6.708a.318.318 \
0 0 0 .317-.317z\
m-4.195 5.557.03\
4-.002a.395.395 \
0 0 0 .31-.196l2\
.294-3.974a.396.\
396 0 0 0-.686-.\
396l-2.01 3.483-\
.92-1.105a.396.3\
96 0 1 0-.61.507\
l1.284 1.54a.396\
.396 0 0 0 .304.\
143zm1.748-6.352\
h2.43l-2.43-2.41\
6z\x22/></svg>\
\x00\x00\x03\x07\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0a<svg fill=\
\x22#000000\x22 width=\
\x22800px\x22 height=\x22\
800px\x22 viewBox=\x22\
-1 0 19 19\x22 xmln\
s=\x22http://www.w3\
.org/2000/svg\x22 c\
lass=\x22cf-icon-sv\
g\x22><path d=\x22M16.\
417 9.583A7.917 \
7.917 0 1 1 8.5 \
1.666a7.917 7.91\
7 0 0 1 7.917 7.\
917zm-2.806 4.02\
9a.396.396 0 0 0\
-.396-.396H4.868\
v-7.94a.396.396 \
0 1 0-.792 0v8.3\
36a.396.396 0 0 \
0 .396.396h8.743\
a.396.396 0 0 0 \
.396-.396zM5.68 \
12.396h1.254V7.9\
38a.318.318 0 0 \
0-.316-.317h-.62\
2a.318.318 0 0 0\
-.316.317zm2.012\
 0h1.255V5.495a.\
318.318 0 0 0-.3\
17-.317h-.62a.31\
8.318 0 0 0-.318\
.317zm2.013 0h1.\
255V7.938a.318.3\
18 0 0 0-.317-.3\
17h-.621a.318.31\
8 0 0 0-.317.317\
zm2.013 0h1.255V\
10.38a.317.317 0\
 0 0-.317-.317h-\
.621a.317.317 0 \
0 0-.317.317z\x22/>\
</svg>\
\x00\x00\x03\x07\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0a<svg fill=\
\x22#000000\x22 width=\
\x22800px\x22 height=\x22\
800px\x22 viewBox=\x22\
-1 0 19 19\x22 xmln\
s=\x22http://www.w3\
.org/2000/svg\x22 c\
lass=\x22cf-icon-sv\
g\x22><path d=\x22M16.\
417 9.583A7.917 \
7.917 0 1 1 8.5 \
1.666a7.917 7.91\
7 0 0 1 7.917 7.\
917zm-2.806 4.02\
9a.396.396 0 0 0\
-.396-.396H4.868\
v-7.94a.396.396 \
0 1 0-.792 0v8.3\
36a.396.396 0 0 \
0 .396.396h8.743\
a.396.396 0 0 0 \
.396-.396zM5.68 \
12.396h1.254V7.9\
38a.318.318 0 0 \
0-.316-.317h-.62\
2a.318.318 0 0 0\
-.316.317zm2.012\
 0h1.255V5.495a.\
318.318 0 0 0-.3\
17-.317h-.62a.31\
8.318 0 0 0-.318\
.317zm2.013 0h1.\
255V7.938a.318.3\
18 0 0 0-.317-.3\
17h-.621a.318.31\
8 0 0 0-.317.317\
zm2.013 0h1.255V\
10.38a.317.317 0\
 0 0-.317-.317h-\
.621a.317.317 0 \
0 0-.317.317z\x22/>\
</svg>\
\x00\x00\x03B\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0d\x0a<svg widt\
h=\x22800px\x22 height\
=\x22800px\x22 viewBox\
=\x220 0 24 24\x22 fil\
l=\x22none\x22 xmlns=\x22\
http://www.w3.or\
g/2000/svg\x22><pat\
h d=\x22M12 22C6.47\
7 22 2 17.523 2 \
12S6.477 2 12 2s\
10 4.477 10 10-4\
.477 10-10 10zM7\
.92 9.234v.102a.\
5.5 0 0 0 .5.5h.\
997a.499.499 0 0\
 0 .499-.499c0-1\
.29.998-1.979 2.\
34-1.979 1.308 0\
 2.168.689 2.168\
 1.67 0 .928-.48\
2 1.359-1.686 1.\
91l-.344.154C11.\
379 11.54 11 12.\
21 11 13.381v.11\
9a.5.5 0 0 0 .5.\
5h.997a.499.499 \
0 0 0 .499-.499c\
0-.516.138-.723.\
55-.912l.345-.15\
5c1.445-.654 2.5\
29-1.514 2.529-3\
.39v-.103c0-1.97\
8-1.72-3.441-4.1\
64-3.441-2.478 0\
-4.336 1.428-4.3\
36 3.734zm2.58 7\
.757c0 .867.659 \
1.509 1.491 1.50\
9.85 0 1.509-.64\
2 1.509-1.509 0-\
.867-.659-1.491-\
1.509-1.491-.832\
 0-1.491.624-1.4\
91 1.491z\x22 fill=\
\x22#000000\x22/></svg\
>\
\x00\x00\x03B\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0d\x0a<svg widt\
h=\x22800px\x22 height\
=\x22800px\x22 viewBox\
=\x220 0 24 24\x22 fil\
l=\x22none\x22 xmlns=\x22\
http://www.w3.or\
g/2000/svg\x22><pat\
h d=\x22M12 22C6.47\
7 22 2 17.523 2 \
12S6.477 2 12 2s\
10 4.477 10 10-4\
.477 10-10 10zM7\
.92 9.234v.102a.\
5.5 0 0 0 .5.5h.\
997a.499.499 0 0\
 0 .499-.499c0-1\
.29.998-1.979 2.\
34-1.979 1.308 0\
 2.168.689 2.168\
 1.67 0 .928-.48\
2 1.359-1.686 1.\
91l-.344.154C11.\
379 11.54 11 12.\
21 11 13.381v.11\
9a.5.5 0 0 0 .5.\
5h.997a.499.499 \
0 0 0 .499-.499c\
0-.516.138-.723.\
55-.912l.345-.15\
5c1.445-.654 2.5\
29-1.514 2.529-3\
.39v-.103c0-1.97\
8-1.72-3.441-4.1\
64-3.441-2.478 0\
-4.336 1.428-4.3\
36 3.734zm2.58 7\
.757c0 .867.659 \
1.509 1.491 1.50\
9.85 0 1.509-.64\
2 1.509-1.509 0-\
.867-.659-1.491-\
1.509-1.491-.832\
 0-1.491.624-1.4\
91 1.491z\x22 fill=\
\x22#000000\x22/></svg\
>\
\x00\x00\x01\xcf\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0a<svg fill=\
\x22#000000\x22 width=\
\x22800px\x22 height=\x22\
800px\x22 viewBox=\x22\
-1 0 19 19\x22 xmln\
s=\x22http://www.w3\
.org/2000/svg\x22 c\
lass=\x22cf-icon-sv\
g\x22><path d=\x22M16.\
416 9.579A7.917 \
7.917 0 1 1 8.5 \
1.662a7.916 7.91\
6 0 0 1 7.916 7.\
917zm-4.16-.606-\
4.81-4.809a.792.\
792 0 1 0-1.12 1\
.12l4.25 4.248-4\
.25 4.25a.792.79\
2 0 0 0 1.12 1.1\
19l4.808-4.809a.\
792.792 0 0 0 0-\
1.12z\x22/></svg>\
\x00\x00\x06>\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0a<svg fill=\
\x22#000000\x22 width=\
\x22800px\x22 height=\x22\
800px\x22 viewBox=\x22\
-1 0 19 19\x22 xmln\
s=\x22http://www.w3\
.org/2000/svg\x22 c\
lass=\x22cf-icon-sv\
g\x22><path d=\x22M16.\
417 9.583A7.917 \
7.917 0 1 1 8.5 \
1.666a7.917 7.91\
7 0 0 1 7.917 7.\
917zm-2.327-.557\
a.391.391 0 0 0-\
.312-.371l-.952-\
.165a.315.315 0 \
0 0-.05-.003 4.3\
86 4.386 0 0 0-.\
467-1.125.344.34\
4 0 0 0 .034-.03\
9l.556-.79a.391.\
391 0 0 0-.041-.\
482l-.81-.81a.39\
1.391 0 0 0-.483\
-.042l-.79.557a.\
315.315 0 0 0-.0\
39.033 4.41 4.41\
 0 0 0-1.124-.46\
6.284.284 0 0 0-\
.004-.05l-.164-.\
952a.391.391 0 0\
 0-.37-.312H7.92\
6a.39.39 0 0 0-.\
37.312l-.165.951\
a.315.315 0 0 0-\
.004.05 4.408 4.\
408 0 0 0-1.125.\
467.293.293 0 0 \
0-.039-.033L5.43\
5 5.2a.391.391 0\
 0 0-.483.042l-.\
81.81a.391.391 0\
 0 0-.042.483l.5\
57.79a.313.313 0\
 0 0 .033.038 4.\
397 4.397 0 0 0-\
.466 1.125.316.3\
16 0 0 0-.05.003\
l-.952.165a.391.\
391 0 0 0-.312.3\
7v1.147a.39.39 0\
 0 0 .312.37l.95\
2.165a.317.317 0\
 0 0 .05.004 4.3\
96 4.396 0 0 0 .\
466 1.124.313.31\
3 0 0 0-.033.04l\
-.557.789a.391.3\
91 0 0 0 .042.48\
2l.81.81a.39.39 \
0 0 0 .483.042l.\
79-.557a.293.293\
 0 0 0 .039-.033\
 4.375 4.375 0 0\
 0 1.124.466.316\
.316 0 0 0 .004.\
051l.164.952a.39\
.39 0 0 0 .371.3\
12h1.146a.391.39\
1 0 0 0 .37-.312\
l.165-.952a.285.\
285 0 0 0 .004-.\
05 4.377 4.377 0\
 0 0 1.124-.467.\
315.315 0 0 0 .0\
4.033l.789.557a.\
39.39 0 0 0 .483\
-.041l.81-.81a.3\
91.391 0 0 0 .04\
2-.483l-.557-.79\
a.344.344 0 0 0-\
.033-.039 4.386 \
4.386 0 0 0 .466\
-1.124.316.316 0\
 0 0 .05-.004l.9\
52-.165a.39.39 0\
 0 0 .312-.37zm-\
3.686.573A1.904 \
1.904 0 1 1 8.5 \
7.695a1.904 1.90\
4 0 0 1 1.904 1.\
904z\x22/></svg>\
\x00\x00\x06>\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0a<svg fill=\
\x22#000000\x22 width=\
\x22800px\x22 height=\x22\
800px\x22 viewBox=\x22\
-1 0 19 19\x22 xmln\
s=\x22http://www.w3\
.org/2000/svg\x22 c\
lass=\x22cf-icon-sv\
g\x22><path d=\x22M16.\
417 9.583A7.917 \
7.917 0 1 1 8.5 \
1.666a7.917 7.91\
7 0 0 1 7.917 7.\
917zm-2.327-.557\
a.391.391 0 0 0-\
.312-.371l-.952-\
.165a.315.315 0 \
0 0-.05-.003 4.3\
86 4.386 0 0 0-.\
467-1.125.344.34\
4 0 0 0 .034-.03\
9l.556-.79a.391.\
391 0 0 0-.041-.\
482l-.81-.81a.39\
1.391 0 0 0-.483\
-.042l-.79.557a.\
315.315 0 0 0-.0\
39.033 4.41 4.41\
 0 0 0-1.124-.46\
6.284.284 0 0 0-\
.004-.05l-.164-.\
952a.391.391 0 0\
 0-.37-.312H7.92\
6a.39.39 0 0 0-.\
37.312l-.165.951\
a.315.315 0 0 0-\
.004.05 4.408 4.\
408 0 0 0-1.125.\
467.293.293 0 0 \
0-.039-.033L5.43\
5 5.2a.391.391 0\
 0 0-.483.042l-.\
81.81a.391.391 0\
 0 0-.042.483l.5\
57.79a.313.313 0\
 0 0 .033.038 4.\
397 4.397 0 0 0-\
.466 1.125.316.3\
16 0 0 0-.05.003\
l-.952.165a.391.\
391 0 0 0-.312.3\
7v1.147a.39.39 0\
 0 0 .312.37l.95\
2.165a.317.317 0\
 0 0 .05.004 4.3\
96 4.396 0 0 0 .\
466 1.124.313.31\
3 0 0 0-.033.04l\
-.557.789a.391.3\
91 0 0 0 .042.48\
2l.81.81a.39.39 \
0 0 0 .483.042l.\
79-.557a.293.293\
 0 0 0 .039-.033\
 4.375 4.375 0 0\
 0 1.124.466.316\
.316 0 0 0 .004.\
051l.164.952a.39\
.39 0 0 0 .371.3\
12h1.146a.391.39\
1 0 0 0 .37-.312\
l.165-.952a.285.\
285 0 0 0 .004-.\
05 4.377 4.377 0\
 0 0 1.124-.467.\
315.315 0 0 0 .0\
4.033l.789.557a.\
39.39 0 0 0 .483\
-.041l.81-.81a.3\
91.391 0 0 0 .04\
2-.483l-.557-.79\
a.344.344 0 0 0-\
.033-.039 4.386 \
4.386 0 0 0 .466\
-1.124.316.316 0\
 0 0 .05-.004l.9\
52-.165a.39.39 0\
 0 0 .312-.37zm-\
3.686.573A1.904 \
1.904 0 1 1 8.5 \
7.695a1.904 1.90\
4 0 0 1 1.904 1.\
904z\x22/></svg>\
\x00\x00\x024\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0a<svg fill=\
\x22#000000\x22 width=\
\x22800px\x22 height=\x22\
800px\x22 viewBox=\x22\
-1 0 19 19\x22 xmln\
s=\x22http://www.w3\
.org/2000/svg\x22 c\
lass=\x22cf-icon-sv\
g\x22><path d=\x22M16.\
417 9.579A7.917 \
7.917 0 1 1 8.5 \
1.662a7.917 7.91\
7 0 0 1 7.917 7.\
917zm-3.56-2.732\
-.805-.805v7.102\
H5.37a.445.445 0\
 0 1-.284-.085.4\
07.407 0 0 1 .00\
5-.64.71.71 0 0 \
1 .454-.08h5.702\
V5.242h-4.16v2.9\
16L6.45 7.69l-.6\
36.468V5.242h-.4\
82A1.209 1.209 0\
 0 0 4.126 6.45v\
6.291a1.209 1.20\
9 0 0 0 1.207 1.\
208h7.524z\x22/></s\
vg>\
\x00\x00\x02#\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0a<svg fill=\
\x22#000000\x22 width=\
\x22800px\x22 height=\x22\
800px\x22 viewBox=\x22\
-1.7 0 20.4 20.4\
\x22 xmlns=\x22http://\
www.w3.org/2000/\
svg\x22 class=\x22cf-i\
con-svg\x22><path d\
=\x22M16.417 10.283\
A7.917 7.917 0 1\
 1 8.5 2.366a7.9\
16 7.916 0 0 1 7\
.917 7.917zm-4.1\
05-4.498a.791.79\
1 0 0 0-1.082.29\
l-3.828 6.63-1.7\
33-2.08a.791.791\
 0 1 0-1.216 1.0\
14l2.459 2.952a.\
792.792 0 0 0 .6\
08.285.83.83 0 0\
 0 .068-.003.791\
.791 0 0 0 .618-\
.393L12.6 6.866a\
.791.791 0 0 0-.\
29-1.081z\x22/></sv\
g>\
\x00\x00\x02\xa6\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0a<svg fill=\
\x22#000000\x22 width=\
\x22800px\x22 height=\x22\
800px\x22 viewBox=\x22\
-1 0 19 19\x22 xmln\
s=\x22http://www.w3\
.org/2000/svg\x22 c\
lass=\x22cf-icon-sv\
g\x22><path d=\x22M16.\
417 9.579A7.917 \
7.917 0 1 1 8.5 \
1.662a7.917 7.91\
7 0 0 1 7.917 7.\
917zm-4.233-1.80\
5H9.259a.318.318\
 0 0 1-.317-.317\
v-2.9H5.16a.317.\
317 0 0 0-.317.3\
17v9.368a.317.31\
7 0 0 0 .317.316\
h6.707a.317.317 \
0 0 0 .317-.316z\
M10.48 10.88a.39\
6.396 0 0 1-.396\
.396H8.877v1.208\
a.396.396 0 1 1-\
.791 0v-1.208H6.\
878a.396.396 0 1\
 1 0-.792h1.208V\
9.277a.396.396 0\
 1 1 .791 0v1.20\
7h1.208a.396.396\
 0 0 1 .396.396z\
m-.744-3.9h2.43l\
-2.43-2.417z\x22/><\
/svg>\
\x00\x00\x02\x17\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0a<svg fill=\
\x22#000000\x22 width=\
\x22800px\x22 height=\x22\
800px\x22 viewBox=\x22\
-1 0 19 19\x22 xmln\
s=\x22http://www.w3\
.org/2000/svg\x22 c\
lass=\x22cf-icon-sv\
g\x22><path d=\x22M16.\
417 9.583A7.917 \
7.917 0 1 1 8.5 \
1.666a7.917 7.91\
7 0 0 1 7.917 7.\
917zm-2.81.002A5\
.107 5.107 0 1 0\
 8.5 14.692a5.10\
7 5.107 0 0 0 5.\
107-5.107zM5.184\
 6.824l6.077 6.0\
77a4.315 4.315 0\
 0 1-6.077-6.077\
zm6.367-.29a4.30\
9 4.309 0 0 1 .2\
7 5.807L5.743 6.\
264a4.31 4.31 0 \
0 1 5.807.27z\x22/>\
</svg>\
\x00\x00\x02\x11\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0a<svg fill=\
\x22#000000\x22 width=\
\x22800px\x22 height=\x22\
800px\x22 viewBox=\x22\
-1 0 19 19\x22 xmln\
s=\x22http://www.w3\
.org/2000/svg\x22 c\
lass=\x22cf-icon-sv\
g\x22><path d=\x22M16.\
416 9.579A7.917 \
7.917 0 1 1 8.5 \
1.662a7.916 7.91\
6 0 0 1 7.916 7.\
917zm-2.753.005a\
.792.792 0 0 0-.\
232-.56l-3.287-3\
.287a.792.792 0 \
0 0-1.12 1.12l1.\
936 1.935H4.128a\
.792.792 0 0 0 0\
 1.583h6.832l-1.\
935 1.936a.792.7\
92 0 0 0 1.12 1.\
12l3.286-3.288a.\
792.792 0 0 0 .2\
32-.56z\x22/></svg>\
\
\x00\x00\x02\x8d\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0a<svg width\
=\x22800px\x22 height=\
\x22800px\x22 viewBox=\
\x220 0 64 64\x22 xmln\
s=\x22http://www.w3\
.org/2000/svg\x22 x\
mlns:xlink=\x22http\
://www.w3.org/19\
99/xlink\x22 aria-h\
idden=\x22true\x22 rol\
e=\x22img\x22 class=\x22i\
conify iconify--\
emojione-monoton\
e\x22 preserveAspec\
tRatio=\x22xMidYMid\
 meet\x22><path d=\x22\
M28.216 35.543h7\
.431l-3.666-11.4\
18z\x22 fill=\x22#0000\
00\x22></path><path\
 d=\x22M32 2C15.432\
 2 2 15.431 2 32\
c0 16.569 13.432\
 30 30 30s30-13.\
432 30-30C62 15.\
431 48.568 2 32 \
2m7.167 44.508l-\
1.914-5.965H26.5\
67L24.6 46.508h-\
6.342l10.358-29.\
016h6.859l10.266\
 29.016h-6.574\x22 \
fill=\x22#000000\x22><\
/path></svg>\
\x00\x00\x02\x8d\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0a<svg width\
=\x22800px\x22 height=\
\x22800px\x22 viewBox=\
\x220 0 64 64\x22 xmln\
s=\x22http://www.w3\
.org/2000/svg\x22 x\
mlns:xlink=\x22http\
://www.w3.org/19\
99/xlink\x22 aria-h\
idden=\x22true\x22 rol\
e=\x22img\x22 class=\x22i\
conify iconify--\
emojione-monoton\
e\x22 preserveAspec\
tRatio=\x22xMidYMid\
 meet\x22><path d=\x22\
M28.216 35.543h7\
.431l-3.666-11.4\
18z\x22 fill=\x22#0000\
00\x22></path><path\
 d=\x22M32 2C15.432\
 2 2 15.431 2 32\
c0 16.569 13.432\
 30 30 30s30-13.\
432 30-30C62 15.\
431 48.568 2 32 \
2m7.167 44.508l-\
1.914-5.965H26.5\
67L24.6 46.508h-\
6.342l10.358-29.\
016h6.859l10.266\
 29.016h-6.574\x22 \
fill=\x22#000000\x22><\
/path></svg>\
\x00\x00\x02\x17\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0a<svg fill=\
\x22#000000\x22 width=\
\x22800px\x22 height=\x22\
800px\x22 viewBox=\x22\
-1.7 0 20.4 20.4\
\x22 xmlns=\x22http://\
www.w3.org/2000/\
svg\x22 class=\x22cf-i\
con-svg\x22><path d\
=\x22M16.417 10.283\
A7.917 7.917 0 1\
 1 8.5 2.366a7.9\
16 7.916 0 0 1 7\
.917 7.917zm-6.8\
04.01 3.032-3.03\
3a.792.792 0 0 0\
-1.12-1.12L8.494\
 9.173 5.46 6.14\
a.792.792 0 0 0-\
1.12 1.12l3.034 \
3.033-3.033 3.03\
3a.792.792 0 0 0\
 1.12 1.119l3.03\
2-3.033 3.033 3.\
033a.792.792 0 0\
 0 1.12-1.12z\x22/>\
</svg>\
\x00\x00\x02\xa1\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0a<svg fill=\
\x22#000000\x22 width=\
\x22800px\x22 height=\x22\
800px\x22 viewBox=\x22\
-1 0 19 19\x22 xmln\
s=\x22http://www.w3\
.org/2000/svg\x22 c\
lass=\x22cf-icon-sv\
g\x22><path d=\x22M16.\
417 9.579A7.917 \
7.917 0 1 1 8.5 \
1.662a7.917 7.91\
7 0 0 1 7.917 7.\
917zm-3.122-2.75\
5a.317.317 0 0 0\
-.317-.317H7.752\
l-.436-.852a.57.\
57 0 0 0-.461-.2\
82H4.038a.318.31\
8 0 0 0-.317.317\
v7.438a.318.318 \
0 0 0 .317.316h8\
.94a.317.317 0 0\
 0 .317-.316zm-2\
.8 3.151a.396.39\
6 0 0 1-.395.396\
H8.862v1.239a.39\
6.396 0 0 1-.792\
 0v-1.239H6.83a.\
396.396 0 1 1 0-\
.791h1.24V8.34a.\
396.396 0 0 1 .7\
92 0v1.24H10.1a.\
396.396 0 0 1 .3\
96.395z\x22/></svg>\
\
\x00\x00\x01\xf1\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0a<svg fill=\
\x22#000000\x22 width=\
\x22800px\x22 height=\x22\
800px\x22 viewBox=\x22\
-1 0 19 19\x22 xmln\
s=\x22http://www.w3\
.org/2000/svg\x22 c\
lass=\x22cf-icon-sv\
g\x22><path d=\x22M16.\
417 9.583A7.917 \
7.917 0 1 1 8.5 \
1.666a7.917 7.91\
7 0 0 1 7.917 7.\
917zm-3.297 3.10\
3-2.424-2.424a3.\
978 3.978 0 1 0-\
1.119 1.12l2.424\
 2.423a.791.791 \
0 1 0 1.119-1.12\
zM9.633 5.808a3.\
189 3.189 0 1 1-\
2.255-.934 3.167\
 3.167 0 0 1 2.2\
55.934z\x22/></svg>\
\
\x00\x00\x01\xa4\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0a<svg fill=\
\x22#000000\x22 width=\
\x22800px\x22 height=\x22\
800px\x22 viewBox=\x22\
0 0 24 24\x22 xmlns\
=\x22http://www.w3.\
org/2000/svg\x22 id\
=\x22check-circle\x22 \
class=\x22icon glyp\
h\x22><path d=\x22M12,\
2A10,10,0,1,0,22\
,12,10,10,0,0,0,\
12,2Zm4.71,8.71-\
5,5a1,1,0,0,1-1.\
42,0l-3-3a1,1,0,\
1,1,1.42-1.42L11\
,13.59l4.29-4.3a\
1,1,0,0,1,1.42,1\
.42Z\x22></path></s\
vg>\
\x00\x00\x01\xa4\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0a<svg fill=\
\x22#000000\x22 width=\
\x22800px\x22 height=\x22\
800px\x22 viewBox=\x22\
0 0 24 24\x22 xmlns\
=\x22http://www.w3.\
org/2000/svg\x22 id\
=\x22check-circle\x22 \
class=\x22icon glyp\
h\x22><path d=\x22M12,\
2A10,10,0,1,0,22\
,12,10,10,0,0,0,\
12,2Zm4.71,8.71-\
5,5a1,1,0,0,1-1.\
42,0l-3-3a1,1,0,\
1,1,1.42-1.42L11\
,13.59l4.29-4.3a\
1,1,0,0,1,1.42,1\
.42Z\x22></path></s\
vg>\
\x00\x00\x03\x0e\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0a<svg fill=\
\x22#000000\x22 width=\
\x22800px\x22 height=\x22\
800px\x22 viewBox=\x22\
-1 0 19 19\x22 xmln\
s=\x22http://www.w3\
.org/2000/svg\x22 c\
lass=\x22cf-icon-sv\
g\x22><path d=\x22M16.\
417 9.579A7.917 \
7.917 0 1 1 8.5 \
1.662a7.917 7.91\
7 0 0 1 7.917 7.\
917zm-3.587-4.05\
a.318.318 0 0 0-\
.317-.317H4.449a\
.317.317 0 0 0-.\
317.317v6.86a.86\
6.866 0 0 0 .226\
.538l.816.8a.895\
.895 0 0 0 .543.\
222h6.796a.318.3\
18 0 0 0 .317-.3\
17zm-1.598 3.066\
a.318.318 0 0 1-\
.316.317h-4.87a.\
317.317 0 0 1-.3\
17-.317V6.22a.31\
7.317 0 0 1 .317\
-.317h4.87a.318.\
318 0 0 1 .316.3\
17zm-.36 1.888v2\
.543a.318.318 0 \
0 1-.317.317H6.4\
a.318.318 0 0 1-\
.316-.317v-2.543\
a.317.317 0 0 1 \
.316-.316h4.155a\
.317.317 0 0 1 .\
316.316zm-3.15.4\
86h-.876v1.591h.\
876z\x22/></svg>\
\x00\x00\x04\xbd\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22?>\x0d\x0a<!-- Uplo\
aded to: SVG Rep\
o, www.svgrepo.c\
om, Generator: S\
VG Repo Mixer To\
ols -->\x0d\x0a<svg wi\
dth=\x22800px\x22 heig\
ht=\x22800px\x22 viewB\
ox=\x220 0 512 512\x22\
 version=\x221.1\x22 x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22 xmlns:xlink=\x22h\
ttp://www.w3.org\
/1999/xlink\x22>\x0d\x0a \
   <title>about-\
filled</title>\x0d\x0a\
    <g id=\x22Page-\
1\x22 stroke=\x22none\x22\
 stroke-width=\x221\
\x22 fill=\x22none\x22 fi\
ll-rule=\x22evenodd\
\x22>\x0d\x0a        <g i\
d=\x22drop\x22 fill=\x22#\
000000\x22 transfor\
m=\x22translate(42.\
666667, 42.66666\
7)\x22>\x0d\x0a          \
  <path d=\x22M213.\
333333,3.5527136\
8e-14 C331.15498\
7,3.55271368e-14\
 426.666667,95.5\
1168 426.666667,\
213.333333 C426.\
666667,331.15370\
7 331.154987,426\
.666667 213.3333\
33,426.666667 C9\
5.51296,426.6666\
67 3.55271368e-1\
4,331.153707 3.5\
5271368e-14,213.\
333333 C3.552713\
68e-14,95.51168 \
95.51296,3.55271\
368e-14 213.3333\
33,3.55271368e-1\
4 Z M234.713387,\
192 L192.04672,1\
92 L192.04672,32\
0 L234.713387,32\
0 L234.713387,19\
2 Z M213.55008,1\
01.333333 C197.9\
9616,101.333333 \
186.713387,112.5\
536 186.713387,1\
27.704107 C186.7\
13387,143.46752 \
197.698773,154.6\
66667 213.55008,\
154.666667 C228.\
785067,154.66666\
7 240.04672,143.\
46752 240.04672,\
128 C240.04672,1\
12.5536 228.7850\
67,101.333333 21\
3.55008,101.3333\
33 Z\x22 id=\x22Shape\x22\
>\x0d\x0a\x0d\x0a</path>\x0d\x0a  \
      </g>\x0d\x0a    \
</g>\x0d\x0a</svg>\
\x00\x00\x04\xbd\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22?>\x0d\x0a<!-- Uplo\
aded to: SVG Rep\
o, www.svgrepo.c\
om, Generator: S\
VG Repo Mixer To\
ols -->\x0d\x0a<svg wi\
dth=\x22800px\x22 heig\
ht=\x22800px\x22 viewB\
ox=\x220 0 512 512\x22\
 version=\x221.1\x22 x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22 xmlns:xlink=\x22h\
ttp://www.w3.org\
/1999/xlink\x22>\x0d\x0a \
   <title>about-\
filled</title>\x0d\x0a\
    <g id=\x22Page-\
1\x22 stroke=\x22none\x22\
 stroke-width=\x221\
\x22 fill=\x22none\x22 fi\
ll-rule=\x22evenodd\
\x22>\x0d\x0a        <g i\
d=\x22drop\x22 fill=\x22#\
000000\x22 transfor\
m=\x22translate(42.\
666667, 42.66666\
7)\x22>\x0d\x0a          \
  <path d=\x22M213.\
333333,3.5527136\
8e-14 C331.15498\
7,3.55271368e-14\
 426.666667,95.5\
1168 426.666667,\
213.333333 C426.\
666667,331.15370\
7 331.154987,426\
.666667 213.3333\
33,426.666667 C9\
5.51296,426.6666\
67 3.55271368e-1\
4,331.153707 3.5\
5271368e-14,213.\
333333 C3.552713\
68e-14,95.51168 \
95.51296,3.55271\
368e-14 213.3333\
33,3.55271368e-1\
4 Z M234.713387,\
192 L192.04672,1\
92 L192.04672,32\
0 L234.713387,32\
0 L234.713387,19\
2 Z M213.55008,1\
01.333333 C197.9\
9616,101.333333 \
186.713387,112.5\
536 186.713387,1\
27.704107 C186.7\
13387,143.46752 \
197.698773,154.6\
66667 213.55008,\
154.666667 C228.\
785067,154.66666\
7 240.04672,143.\
46752 240.04672,\
128 C240.04672,1\
12.5536 228.7850\
67,101.333333 21\
3.55008,101.3333\
33 Z\x22 id=\x22Shape\x22\
>\x0d\x0a\x0d\x0a</path>\x0d\x0a  \
      </g>\x0d\x0a    \
</g>\x0d\x0a</svg>\
\x00\x00\x03\xeb\
<\
?xml version=\x221.\
0\x22 ?>\x0a\x0d<!-- Uplo\
aded to: SVG Rep\
o, www.svgrepo.c\
om, Generator: S\
VG Repo Mixer To\
ols -->\x0a<svg fil\
l=\x22#000000\x22 widt\
h=\x22800px\x22 height\
=\x22800px\x22 viewBox\
=\x220 0 512 512\x22 i\
d=\x22_x30_1\x22 versi\
on=\x221.1\x22 xml:spa\
ce=\x22preserve\x22 xm\
lns=\x22http://www.\
w3.org/2000/svg\x22\
 xmlns:xlink=\x22ht\
tp://www.w3.org/\
1999/xlink\x22>\x0a\x0d<g\
>\x0a\x0d<path d=\x22M256\
,0C114.615,0,0,1\
14.615,0,256s114\
.615,256,256,256\
s256-114.615,256\
-256S397.385,0,2\
56,0z M404.861,2\
63.236   L404.86\
1,263.236c-7.297\
,7.297-18.066,8.\
993-26.986,5.104\
v97.098c0,20.193\
-16.37,36.562-36\
.562,36.562H170.\
688   c-20.193,0\
-36.562-16.37-36\
.562-36.562v-97.\
098c-8.919,3.89-\
19.689,2.193-26.\
986-5.104c-9.519\
-9.519-9.519-24.\
952,0-34.471   L\
238.764,97.139h0\
c9.519-9.519,24.\
952-9.519,34.471\
,0l131.625,131.6\
25C414.38,238.28\
3,414.38,253.717\
,404.861,263.236\
z\x22/>\x0a\x0d<path d=\x22M\
286.469,267.938h\
-60.938c-6.731,0\
-12.188,5.457-12\
.188,12.188v73.1\
25c0,6.731,5.457\
,12.188,12.188,1\
2.188h60.938   c\
6.731,0,12.188-5\
.457,12.188-12.1\
88v-73.125C298.6\
56,273.394,293.2\
,267.938,286.469\
,267.938z\x22/>\x0a\x0d</\
g>\x0a\x0d</svg>\
\x00\x00\x03\xeb\
<\
?xml version=\x221.\
0\x22 ?>\x0a\x0d<!-- Uplo\
aded to: SVG Rep\
o, www.svgrepo.c\
om, Generator: S\
VG Repo Mixer To\
ols -->\x0a<svg fil\
l=\x22#000000\x22 widt\
h=\x22800px\x22 height\
=\x22800px\x22 viewBox\
=\x220 0 512 512\x22 i\
d=\x22_x30_1\x22 versi\
on=\x221.1\x22 xml:spa\
ce=\x22preserve\x22 xm\
lns=\x22http://www.\
w3.org/2000/svg\x22\
 xmlns:xlink=\x22ht\
tp://www.w3.org/\
1999/xlink\x22>\x0a\x0d<g\
>\x0a\x0d<path d=\x22M256\
,0C114.615,0,0,1\
14.615,0,256s114\
.615,256,256,256\
s256-114.615,256\
-256S397.385,0,2\
56,0z M404.861,2\
63.236   L404.86\
1,263.236c-7.297\
,7.297-18.066,8.\
993-26.986,5.104\
v97.098c0,20.193\
-16.37,36.562-36\
.562,36.562H170.\
688   c-20.193,0\
-36.562-16.37-36\
.562-36.562v-97.\
098c-8.919,3.89-\
19.689,2.193-26.\
986-5.104c-9.519\
-9.519-9.519-24.\
952,0-34.471   L\
238.764,97.139h0\
c9.519-9.519,24.\
952-9.519,34.471\
,0l131.625,131.6\
25C414.38,238.28\
3,414.38,253.717\
,404.861,263.236\
z\x22/>\x0a\x0d<path d=\x22M\
286.469,267.938h\
-60.938c-6.731,0\
-12.188,5.457-12\
.188,12.188v73.1\
25c0,6.731,5.457\
,12.188,12.188,1\
2.188h60.938   c\
6.731,0,12.188-5\
.457,12.188-12.1\
88v-73.125C298.6\
56,273.394,293.2\
,267.938,286.469\
,267.938z\x22/>\x0a\x0d</\
g>\x0a\x0d</svg>\
\x00\x00\x01\xc6\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0a<svg fill=\
\x22#000000\x22 width=\
\x22800px\x22 height=\x22\
800px\x22 viewBox=\x22\
-1 0 19 19\x22 xmln\
s=\x22http://www.w3\
.org/2000/svg\x22 c\
lass=\x22cf-icon-sv\
g\x22><path d=\x22M16.\
416 9.579A7.917 \
7.917 0 1 1 8.5 \
1.662a7.916 7.91\
6 0 0 1 7.916 7.\
917zm-9.992.046 \
4.248-4.248a.792\
.792 0 0 0-1.12-\
1.12L4.745 9.066\
a.792.792 0 0 0 \
0 1.12l4.809 4.8\
08a.792.792 0 0 \
0 1.12-1.12z\x22/><\
/svg>\
\x00\x00\x02{\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0a<svg fill=\
\x22#000000\x22 width=\
\x22800px\x22 height=\x22\
800px\x22 viewBox=\x22\
-1 0 19 19\x22 xmln\
s=\x22http://www.w3\
.org/2000/svg\x22 c\
lass=\x22cf-icon-sv\
g\x22><path d=\x22M16.\
417 9.583A7.917 \
7.917 0 1 1 8.5 \
1.666a7.917 7.91\
7 0 0 1 7.917 7.\
917zM13.18 6.811\
a.794.794 0 0 0-\
.791-.792H4.654a\
.794.794 0 0 0-.\
791.792v5.187a.7\
94.794 0 0 0 .79\
1.791h2.93L8.338\
 14a.182.182 0 0\
 0 .335 0l.755-1\
.21h2.96a.794.79\
4 0 0 0 .791-.79\
2zM9.025 11.1a.5\
03.503 0 1 1-.50\
3-.503.503.503 0\
 0 1 .503.503zm-\
.9-1.278V7.515a.\
396.396 0 0 1 .7\
93 0v2.307a.396.\
396 0 1 1-.792 0\
z\x22/></svg>\
\x00\x00\x02\x0f\
<\
?xml version=\x221.\
0\x22 ?>\x0a\x0d<!-- Uplo\
aded to: SVG Rep\
o, www.svgrepo.c\
om, Generator: S\
VG Repo Mixer To\
ols -->\x0a<svg wid\
th=\x22800px\x22 heigh\
t=\x22800px\x22 viewBo\
x=\x220 0 12 12\x22 en\
able-background=\
\x22new 0 0 12 12\x22 \
id=\x22\xd0\xa1\xd0\xbb\xd0\xbe\xd0\xb9_1\x22 \
version=\x221.1\x22 xm\
l:space=\x22preserv\
e\x22 xmlns=\x22http:/\
/www.w3.org/2000\
/svg\x22 xmlns:xlin\
k=\x22http://www.w3\
.org/1999/xlink\x22\
>\x0a\x0d<g>\x0a\x0d<rect fi\
ll=\x22#1D1D1B\x22 hei\
ght=\x221\x22 width=\x221\
1\x22 x=\x220.5\x22 y=\x225.\
5\x22/>\x0a\x0d<rect fill\
=\x22#1D1D1B\x22 heigh\
t=\x221\x22 width=\x2211\x22\
 x=\x220.5\x22 y=\x222.5\x22\
/>\x0a\x0d<rect fill=\x22\
#1D1D1B\x22 height=\
\x221\x22 width=\x2211\x22 x\
=\x220.5\x22 y=\x228.5\x22/>\
\x0a\x0d</g>\x0a\x0d</svg>\
\x00\x00\x02\x0f\
<\
?xml version=\x221.\
0\x22 ?>\x0a\x0d<!-- Uplo\
aded to: SVG Rep\
o, www.svgrepo.c\
om, Generator: S\
VG Repo Mixer To\
ols -->\x0a<svg wid\
th=\x22800px\x22 heigh\
t=\x22800px\x22 viewBo\
x=\x220 0 12 12\x22 en\
able-background=\
\x22new 0 0 12 12\x22 \
id=\x22\xd0\xa1\xd0\xbb\xd0\xbe\xd0\xb9_1\x22 \
version=\x221.1\x22 xm\
l:space=\x22preserv\
e\x22 xmlns=\x22http:/\
/www.w3.org/2000\
/svg\x22 xmlns:xlin\
k=\x22http://www.w3\
.org/1999/xlink\x22\
>\x0a\x0d<g>\x0a\x0d<rect fi\
ll=\x22#1D1D1B\x22 hei\
ght=\x221\x22 width=\x221\
1\x22 x=\x220.5\x22 y=\x225.\
5\x22/>\x0a\x0d<rect fill\
=\x22#1D1D1B\x22 heigh\
t=\x221\x22 width=\x2211\x22\
 x=\x220.5\x22 y=\x222.5\x22\
/>\x0a\x0d<rect fill=\x22\
#1D1D1B\x22 height=\
\x221\x22 width=\x2211\x22 x\
=\x220.5\x22 y=\x228.5\x22/>\
\x0a\x0d</g>\x0a\x0d</svg>\
\x00\x00\x051\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Uplo\
aded to: SVG Rep\
o, www.svgrepo.c\
om, Generator: S\
VG Repo Mixer To\
ols -->\x0d\x0a<svg wi\
dth=\x22800px\x22 heig\
ht=\x22800px\x22 viewB\
ox=\x220 0 32 32\x22 v\
ersion=\x221.1\x22 xml\
ns=\x22http://www.w\
3.org/2000/svg\x22 \
xmlns:xlink=\x22htt\
p://www.w3.org/1\
999/xlink\x22 xmlns\
:sketch=\x22http://\
www.bohemiancodi\
ng.com/sketch/ns\
\x22>\x0d\x0a    \x0d\x0a    <t\
itle>plus-circle\
</title>\x0d\x0a    <d\
esc>Created with\
 Sketch Beta.</d\
esc>\x0d\x0a    <defs>\
\x0d\x0a\x0d\x0a</defs>\x0d\x0a   \
 <g id=\x22Page-1\x22 \
stroke=\x22none\x22 st\
roke-width=\x221\x22 f\
ill=\x22none\x22 fill-\
rule=\x22evenodd\x22 s\
ketch:type=\x22MSPa\
ge\x22>\x0d\x0a        <g\
 id=\x22Icon-Set-Fi\
lled\x22 sketch:typ\
e=\x22MSLayerGroup\x22\
 transform=\x22tran\
slate(-466.00000\
0, -1089.000000)\
\x22 fill=\x22#000000\x22\
>\x0d\x0a            <\
path d=\x22M488,110\
6 L483,1106 L483\
,1111 C483,1111.\
55 482.553,1112 \
482,1112 C481.44\
7,1112 481,1111.\
55 481,1111 L481\
,1106 L476,1106 \
C475.447,1106 47\
5,1105.55 475,11\
05 C475,1104.45 \
475.447,1104 476\
,1104 L481,1104 \
L481,1099 C481,1\
098.45 481.447,1\
098 482,1098 C48\
2.553,1098 483,1\
098.45 483,1099 \
L483,1104 L488,1\
104 C488.553,110\
4 489,1104.45 48\
9,1105 C489,1105\
.55 488.553,1106\
 488,1106 L488,1\
106 Z M482,1089 \
C473.163,1089 46\
6,1096.16 466,11\
05 C466,1113.84 \
473.163,1121 482\
,1121 C490.837,1\
121 498,1113.84 \
498,1105 C498,10\
96.16 490.837,10\
89 482,1089 L482\
,1089 Z\x22 id=\x22plu\
s-circle\x22 sketch\
:type=\x22MSShapeGr\
oup\x22>\x0d\x0a\x0d\x0a</path>\
\x0d\x0a        </g>\x0d\x0a\
    </g>\x0d\x0a</svg>\
\
\x00\x00\x051\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0d\x0a<!-- Uplo\
aded to: SVG Rep\
o, www.svgrepo.c\
om, Generator: S\
VG Repo Mixer To\
ols -->\x0d\x0a<svg wi\
dth=\x22800px\x22 heig\
ht=\x22800px\x22 viewB\
ox=\x220 0 32 32\x22 v\
ersion=\x221.1\x22 xml\
ns=\x22http://www.w\
3.org/2000/svg\x22 \
xmlns:xlink=\x22htt\
p://www.w3.org/1\
999/xlink\x22 xmlns\
:sketch=\x22http://\
www.bohemiancodi\
ng.com/sketch/ns\
\x22>\x0d\x0a    \x0d\x0a    <t\
itle>plus-circle\
</title>\x0d\x0a    <d\
esc>Created with\
 Sketch Beta.</d\
esc>\x0d\x0a    <defs>\
\x0d\x0a\x0d\x0a</defs>\x0d\x0a   \
 <g id=\x22Page-1\x22 \
stroke=\x22none\x22 st\
roke-width=\x221\x22 f\
ill=\x22none\x22 fill-\
rule=\x22evenodd\x22 s\
ketch:type=\x22MSPa\
ge\x22>\x0d\x0a        <g\
 id=\x22Icon-Set-Fi\
lled\x22 sketch:typ\
e=\x22MSLayerGroup\x22\
 transform=\x22tran\
slate(-466.00000\
0, -1089.000000)\
\x22 fill=\x22#000000\x22\
>\x0d\x0a            <\
path d=\x22M488,110\
6 L483,1106 L483\
,1111 C483,1111.\
55 482.553,1112 \
482,1112 C481.44\
7,1112 481,1111.\
55 481,1111 L481\
,1106 L476,1106 \
C475.447,1106 47\
5,1105.55 475,11\
05 C475,1104.45 \
475.447,1104 476\
,1104 L481,1104 \
L481,1099 C481,1\
098.45 481.447,1\
098 482,1098 C48\
2.553,1098 483,1\
098.45 483,1099 \
L483,1104 L488,1\
104 C488.553,110\
4 489,1104.45 48\
9,1105 C489,1105\
.55 488.553,1106\
 488,1106 L488,1\
106 Z M482,1089 \
C473.163,1089 46\
6,1096.16 466,11\
05 C466,1113.84 \
473.163,1121 482\
,1121 C490.837,1\
121 498,1113.84 \
498,1105 C498,10\
96.16 490.837,10\
89 482,1089 L482\
,1089 Z\x22 id=\x22plu\
s-circle\x22 sketch\
:type=\x22MSShapeGr\
oup\x22>\x0d\x0a\x0d\x0a</path>\
\x0d\x0a        </g>\x0d\x0a\
    </g>\x0d\x0a</svg>\
\
"

qt_resource_name = b"\
\x00\x05\
\x00O\xa6S\
\x00I\
\x00c\x00o\x00n\x00s\
\x00\x0a\
\x0a\xc8\xfa\xa7\
\x00f\
\x00i\x00l\x00t\x00e\x00r\x00.\x00s\x00v\x00g\
\x00\x0c\
\x09<\x02\xa7\
\x00d\
\x00o\x00c\x00u\x00m\x00e\x00n\x00t\x00.\x00s\x00v\x00g\
\x00\x09\
\x09e\x83\xe7\
\x00e\
\x00r\x00r\x00o\x00r\x00.\x00s\x00v\x00g\
\x00\x10\
\x0f\xaf\xdf'\
\x00s\
\x00u\x00c\x00c\x00e\x00s\x00s\x00_\x00f\x00i\x00l\x00e\x00.\x00s\x00v\x00g\
\x00\x07\
\x08\x85Z\x07\
\x00b\
\x00a\x00r\x00.\x00s\x00v\x00g\
\x00\x08\
\x0c3W\x07\
\x00h\
\x00e\x00l\x00p\x00.\x00s\x00v\x00g\
\x00\x0f\
\x0cp)G\
\x00a\
\x00r\x00r\x00o\x00w\x00_\x00r\x00i\x00g\x00t\x00h\x00.\x00s\x00v\x00g\
\x00\x0c\
\x0b\xdf,\xc7\
\x00s\
\x00e\x00t\x00t\x00i\x00n\x00g\x00s\x00.\x00s\x00v\x00g\
\x00\x08\
\x06^W\xe7\
\x00b\
\x00o\x00o\x00k\x00.\x00s\x00v\x00g\
\x00\x0e\
\x05\xfal\xc7\
\x00c\
\x00h\x00e\x00c\x00k\x00_\x00m\x00a\x00r\x00k\x00.\x00s\x00v\x00g\
\x00\x10\
\x0f%\x9bg\
\x00a\
\x00d\x00d\x00-\x00d\x00o\x00c\x00u\x00m\x00e\x00n\x00t\x00.\x00s\x00v\x00g\
\x00\x0d\
\x00\x90D'\
\x00f\
\x00o\x00r\x00b\x00i\x00d\x00d\x00e\x00n\x00.\x00s\x00v\x00g\
\x00\x09\
\x09j\x8b\xe7\
\x00a\
\x00r\x00r\x00o\x00w\x00.\x00s\x00v\x00g\
\x00\x0d\
\x01a\xd0\x87\
\x00m\
\x00a\x00i\x00n\x00_\x00i\x00c\x00o\x00n\x00.\x00s\x00v\x00g\
\x00\x05\
\x00{Z\xc7\
\x00x\
\x00.\x00s\x00v\x00g\
\x00\x0e\
\x0b\xf2\xcb\xe7\
\x00f\
\x00o\x00l\x00d\x00e\x00r\x00-\x00a\x00d\x00d\x00.\x00s\x00v\x00g\
\x00\x0a\
\x08\x94m\xc7\
\x00s\
\x00e\x00a\x00r\x00c\x00h\x00.\x00s\x00v\x00g\
\x00\x09\
\x0b\x9e\x89\x07\
\x00c\
\x00h\x00e\x00c\x00k\x00.\x00s\x00v\x00g\
\x00\x0d\
\x0e\xd4vG\
\x00d\
\x00i\x00s\x00k\x00_\x00s\x00a\x00v\x00e\x00.\x00s\x00v\x00g\
\x00\x09\
\x06\xc7\x95\xe7\
\x00a\
\x00b\x00o\x00u\x00t\x00.\x00s\x00v\x00g\
\x00\x08\
\x068W'\
\x00h\
\x00o\x00m\x00e\x00.\x00s\x00v\x00g\
\x00\x0e\
\x08\xfa\xec\xa7\
\x00a\
\x00r\x00r\x00o\x00w\x00_\x00l\x00e\x00f\x00t\x00.\x00s\x00v\x00g\
\x00\x13\
\x0b6\x8d'\
\x00w\
\x00a\x00r\x00n\x00i\x00n\x00g\x00_\x00m\x00e\x00s\x00s\x00a\x00g\x00e\x00.\x00s\
\x00v\x00g\
\x00\x0a\
\x0d\xc8c\xc7\
\x00b\
\x00u\x00r\x00g\x00e\x00r\x00.\x00s\x00v\x00g\
\x00\x08\
\x03\xc6T'\
\x00p\
\x00l\x00u\x00s\x00.\x00s\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00$\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x01\xa8\x00\x00\x00\x00\x00\x01\x00\x00?!\
\x00\x00\x01\x89\xe1\x7f\xc4k\
\x00\x00\x01P\x00\x00\x00\x00\x00\x01\x00\x005\xcf\
\x00\x00\x01\x89\xe1\x82\x0f\xbe\
\x00\x00\x01\x88\x00\x00\x00\x00\x00\x01\x00\x009\xff\
\x00\x00\x01\x89,\xd8\xdf~\
\x00\x00\x01\x88\x00\x00\x00\x00\x00\x01\x00\x00<\x90\
\x00\x00\x01\x89,\xd8\xdf~\
\x00\x00\x02\xc2\x00\x00\x00\x00\x00\x01\x00\x00k<\
\x00\x00\x01\x89r[\x07+\
\x00\x00\x02\xc2\x00\x00\x00\x00\x00\x01\x00\x00f\x07\
\x00\x00\x01\x89r[\x07+\
\x00\x00\x01\x08\x00\x00\x00\x00\x00\x01\x00\x000\xfe\
\x00\x00\x01\x89\xe1\x807\xf8\
\x00\x00\x02D\x00\x00\x00\x00\x00\x01\x00\x00U\xba\
\x00\x00\x01\x89\x84n\xdaQ\
\x00\x00\x02D\x00\x00\x00\x00\x00\x01\x00\x00Y\xa9\
\x00\x00\x01\x89\x84n\xdaQ\
\x00\x00\x00\xf2\x00\x00\x00\x00\x00\x01\x00\x00.\xc6\
\x00\x00\x01\x89\xe1\x80}\xcb\
\x00\x00\x02,\x00\x00\x00\x00\x00\x01\x00\x00L8\
\x00\x00\x01\x89rR\xed\xf5\
\x00\x00\x02,\x00\x00\x00\x00\x00\x01\x00\x00P\xf9\
\x00\x00\x01\x89rR\xed\xf5\
\x00\x00\x00\x86\x00\x00\x00\x00\x00\x01\x00\x00\x13\xcd\
\x00\x00\x01\x89rY\x7f\x8e\
\x00\x00\x00\x86\x00\x00\x00\x00\x00\x01\x00\x00\x16\xd8\
\x00\x00\x01\x89rY\x7f\x8e\
\x00\x00\x01\xda\x00\x00\x00\x00\x00\x01\x00\x00C\xe1\
\x00\x00\x01\x89\xe1\x7f\xe0\x9e\
\x00\x00\x02Z\x00\x00\x00\x00\x00\x01\x00\x00]\x98\
\x00\x00\x01\x89\xe1\x80\xaf\xc9\
\x00\x00\x00*\x00\x00\x00\x00\x00\x01\x00\x00\x03\xcd\
\x00\x00\x01\x89rW\x98\x9c\
\x00\x00\x00*\x00\x00\x00\x00\x00\x01\x00\x00\x07\xfe\
\x00\x00\x01\x89rW\x98\x9c\
\x00\x00\x00H\x00\x00\x00\x00\x00\x01\x00\x00\x0c/\
\x00\x00\x01\x89rT\xbcl\
\x00\x00\x00H\x00\x00\x00\x00\x00\x01\x00\x00\x0e\xae\
\x00\x00\x01\x89rT\xbcl\
\x00\x00\x01p\x00\x00\x00\x00\x00\x01\x00\x007\xea\
\x00\x00\x01\x89\xe1\x80&\xf1\
\x00\x00\x00\x10\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x89\xe1\x7f~\xe3\
\x00\x00\x02|\x00\x00\x00\x00\x00\x01\x00\x00_b\
\x00\x00\x01\x89\xe1\x80\xda\x7f\
\x00\x00\x01\xf4\x00\x00\x00\x00\x00\x01\x00\x00E\xd6\
\x00\x00\x01\x89\x84t\x87J\
\x00\x00\x01\xf4\x00\x00\x00\x00\x00\x01\x00\x00G~\
\x00\x00\x01\x89\x84t\x87J\
\x00\x00\x00\xd4\x00\x00\x00\x00\x00\x01\x00\x00\x22B\
\x00\x00\x01\x89\xe1\x82;S\
\x00\x00\x00\xd4\x00\x00\x00\x00\x00\x01\x00\x00(\x84\
\x00\x00\x01\x89\xe1\x82;S\
\x00\x00\x01\xb8\x00\x00\x00\x00\x00\x01\x00\x00A<\
\x00\x00\x01\x89\xe1\x81\x8f{\
\x00\x00\x00\x9a\x00\x00\x00\x00\x00\x01\x00\x00\x19\xe3\
\x00\x00\x01\x89r0\x105\
\x00\x00\x00\x9a\x00\x00\x00\x00\x00\x01\x00\x00\x1d)\
\x00\x00\x01\x89r0\x105\
\x00\x00\x00\xb0\x00\x00\x00\x00\x00\x01\x00\x00 o\
\x00\x00\x01\x89\xe1\x80\xbe-\
\x00\x00\x02\xa8\x00\x00\x00\x00\x00\x01\x00\x00a\xe1\
\x00\x00\x01\x89r\xcaSU\
\x00\x00\x02\xa8\x00\x00\x00\x00\x00\x01\x00\x00c\xf4\
\x00\x00\x01\x89r\xcaSU\
\x00\x00\x02\x0c\x00\x00\x00\x00\x00\x01\x00\x00I&\
\x00\x00\x01\x89\xe1\x81\x1c\x8e\
\x00\x00\x01*\x00\x00\x00\x00\x00\x01\x00\x003%\
\x00\x00\x01\x89\xe1\x80\x04\x07\
\x00\x00\x00`\x00\x00\x00\x00\x00\x01\x00\x00\x11-\
\x00\x00\x01\x89\xe1\x81\x04E\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
