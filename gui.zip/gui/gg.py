from PySide6.QtSql import QSqlDatabase
from PySide6.QtWidgets import QApplication
import config_db as dbc
app = QApplication([])


db = QSqlDatabase.addDatabase('QPSQL')
db.setHostName(dbc.db_params['host'])
db.setDatabaseName(dbc.db_params['database'])
db.setPort(dbc.db_params['port'])
db.setUserName(dbc.db_params['user'])
db.setPassword(dbc.db_params['password'])

if not db.open():
    print("Unable to connect.")
    print('Last error', db.lastError().text())
else:
    print("Connection to the database successful")