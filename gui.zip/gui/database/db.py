import psycopg2
from config_db import db_params

class DatabaseManager:
    def __init__(self):
        self.conn = psycopg2.connect(database=db_params['database'], user=db_params['user'], password=db_params['password'],
                                     host=db_params['host'], port=db_params['port'])
        self.cur = self.conn.cursor()
        if self.conn:
            print("Ok")
        else:
            print('not ok')


    def execute_query(self, query):
        self.cur.execute(query)
        return self.cur.fetchall()

if __name__ == '__main__':
    example= DatabaseManager()