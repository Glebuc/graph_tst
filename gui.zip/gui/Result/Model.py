from PySide6.QtCore import Qt, QAbstractTableModel, QModelIndex
from PySide6.QtGui import QColor



import logging
LOG = logging.getLogger(__name__)
LOG.setLevel(logging.DEBUG)

from exceptions import MyQtSqlModeError


SELECT_ALL = '''
    SELECT test_name, test_param, test_note, test_id, id_user_fk, start_test, time_test
    FROM tests;

'''


SELECT_ONE = '''
    SELECT test_name, test_param, test_note, test_id, id_user_fk, start_test, time_test
FROM tests WHERE id=%s;
'''


UPDATE = '''
    update tests set
           test_name = %s,
           test_param = %s,
           test_note = %s,
           test_id = %s,
           start_test = %s,
           time_test = %s
        where id = %s ;
'''


DELETE = '''
    delete from tests where id = %s ;
'''


class CustomTableModel(QAbstractTableModel):
    def __init__(self, data=None):
        QAbstractTableModel.__init__(self)
        self.load_data(data)

    def load_data(self, data):
        self.input_dates = data[0].values
        self.input_magnitudes = data[1].values

        self.column_count = 2
        self.row_count = len(self.input_magnitudes)

    def rowCount(self, parent=QModelIndex()):
        return self.row_count

    def columnCount(self, parent=QModelIndex()):
        return self.column_count

    def headerData(self, section, orientation, role):
        if role != Qt.DisplayRole:
            return None
        if orientation == Qt.Horizontal:
            return ("Date", "Magnitude")[section]
        else:
            return f"{section}"

    def data(self, index, role=Qt.DisplayRole):
        column = index.column()
        row = index.row()

        if role == Qt.DisplayRole:
            if column == 0:
                date = self.input_dates[row].toPython()
                return str(date)[:-3]
            elif column == 1:
                magnitude = self.input_magnitudes[row]
                return f"{magnitude:.2f}"
        elif role == Qt.BackgroundRole:
            return QColor(Qt.white)
        elif role == Qt.TextAlignmentRole:
            return Qt.AlignRight

        return None


