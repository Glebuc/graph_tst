from PySide6.QtWidgets import QTableView, QMessageBox
from PySide6.QtCore import Slot


from .Model import Model


import logging
LOG = logging.getLogger(__name__)
LOG.setLevel(logging.DEBUG)


SELECT_ONE = '''
    select f_fio, f_phone, f_email, f_comment
        from teacher
        where id = %s ;
'''


class View(QTableView):

    def __init__(self, parent=None):
        super().__init__(parent)

        LOG.debug('Creating Teachers.View')

        model = Model(parent=self)
        self.setModel(model)

        LOG.debug('Creating Tests.View: Model Installed')

        self.setSelectionBehavior(self.SelectRows)
        self.setSelectionMode(self.SingleSelection)
        self.hideColumn(0)
        self.setWordWrap(False)

        vh = self.verticalHeader()
        vh.setSectionResizeMode(vh.Fixed)

        hh = self.horizontalHeader()
        hh.setSectionResizeMode(hh.ResizeToContents)
        hh.setSectionResizeMode(4, hh.Stretch)

        LOG.debug('Creating Test.View: Finished')

