class MyQtSqlModeError(Exception): pass
