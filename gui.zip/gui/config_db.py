db_params = {
    "host" : "127.0.0.1",
    "port": 5433,
    "user":"postgres",
    "password": "admin",
    "database": "postgres"
}



global_salt = 'f549eebfba38656a649719c910f054f229e5fc93'